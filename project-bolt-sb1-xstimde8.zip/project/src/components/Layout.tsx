import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import NotificationBanner from './NotificationBanner';
import { useSelector } from 'react-redux';
import { RootState } from '../store';

const Layout: React.FC = () => {
  const { notification } = useSelector((state: RootState) => state.ui);

  return (
    <div className="flex flex-col min-h-screen">
      {notification.show && (
        <NotificationBanner
          message={notification.message}
          type={notification.type}
        />
      )}
      <Header />
      <main className="flex-grow">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
};

export default Layout;