import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { hideNotification } from '../store/slices/uiSlice';
import { X, AlertCircle, CheckCircle, Info, AlertTriangle } from 'lucide-react';

interface NotificationBannerProps {
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

const NotificationBanner: React.FC<NotificationBannerProps> = ({ message, type }) => {
  const dispatch = useDispatch();

  useEffect(() => {
    const timer = setTimeout(() => {
      dispatch(hideNotification());
    }, 5000);

    return () => clearTimeout(timer);
  }, [dispatch]);

  const handleClose = () => {
    dispatch(hideNotification());
  };

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'error':
        return <AlertCircle className="text-red-500" size={20} />;
      case 'warning':
        return <AlertTriangle className="text-yellow-500" size={20} />;
      case 'info':
      default:
        return <Info className="text-blue-500" size={20} />;
    }
  };

  const getBgColor = () => {
    switch (type) {
      case 'success':
        return 'bg-green-50 border-green-200';
      case 'error':
        return 'bg-red-50 border-red-200';
      case 'warning':
        return 'bg-yellow-50 border-yellow-200';
      case 'info':
      default:
        return 'bg-blue-50 border-blue-200';
    }
  };

  const getTextColor = () => {
    switch (type) {
      case 'success':
        return 'text-green-800';
      case 'error':
        return 'text-red-800';
      case 'warning':
        return 'text-yellow-800';
      case 'info':
      default:
        return 'text-blue-800';
    }
  };

  return (
    <div className={`w-full border-b ${getBgColor()}`}>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getIcon()}
            <p className={`text-sm font-medium ${getTextColor()}`}>{message}</p>
          </div>
          <button
            onClick={handleClose}
            className={`${getTextColor()} hover:opacity-75 transition-opacity`}
          >
            <X size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotificationBanner;