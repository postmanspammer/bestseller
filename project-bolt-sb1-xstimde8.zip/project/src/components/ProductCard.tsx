import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../store/slices/productSlice';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  // Get the lowest price from all plans
  const lowestPrice = product.plans.reduce(
    (min, plan) => (plan.price < min ? plan.price : min),
    product.plans[0]?.price || 0
  );

  return (
    <div className="card group hover:shadow-lg transition-shadow duration-300">
      <div className="p-6 flex flex-col items-center">
        <img
          src={product.logoUrl}
          alt={`${product.name} logo`}
          className="h-24 w-24 object-contain mb-4"
        />
        <h3 className="text-xl font-semibold text-center mb-2">{product.name}</h3>
        <p className="text-gray-600 text-center mb-4 line-clamp-2">
          {product.description}
        </p>
        <div className="text-center mb-4">
          <span className="text-sm text-gray-500">Starting from</span>
          <p className="text-2xl font-bold text-yellow-600">${lowestPrice.toFixed(2)}</p>
        </div>
        <Link
          to={`/product/${product.id}`}
          className="btn btn-primary w-full text-center"
        >
          View Plans
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;