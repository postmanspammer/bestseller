import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Package, ShoppingBag, Users, Settings } from 'lucide-react';

const AdminSidebar: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="bg-slate-800 text-white w-64 min-h-screen p-4">
      <div className="flex items-center space-x-2 mb-8">
        <img src="/favicon.svg" alt="BundleStore Logo" className="h-8 w-8" />
        <span className="text-xl font-bold">Admin Panel</span>
      </div>

      <nav className="space-y-2">
        <Link
          to="/admin"
          className={`flex items-center space-x-2 p-3 rounded-md transition-colors ${
            isActive('/admin')
              ? 'bg-yellow-500 text-white'
              : 'text-gray-300 hover:bg-slate-700'
          }`}
        >
          <LayoutDashboard size={20} />
          <span>Dashboard</span>
        </Link>

        <Link
          to="/admin/products"
          className={`flex items-center space-x-2 p-3 rounded-md transition-colors ${
            isActive('/admin/products')
              ? 'bg-yellow-500 text-white'
              : 'text-gray-300 hover:bg-slate-700'
          }`}
        >
          <Package size={20} />
          <span>Products</span>
        </Link>

        <Link
          to="/admin/orders"
          className={`flex items-center space-x-2 p-3 rounded-md transition-colors ${
            isActive('/admin/orders')
              ? 'bg-yellow-500 text-white'
              : 'text-gray-300 hover:bg-slate-700'
          }`}
        >
          <ShoppingBag size={20} />
          <span>Orders</span>
        </Link>

        <Link
          to="/admin/customers"
          className={`flex items-center space-x-2 p-3 rounded-md transition-colors ${
            isActive('/admin/customers')
              ? 'bg-yellow-500 text-white'
              : 'text-gray-300 hover:bg-slate-700'
          }`}
        >
          <Users size={20} />
          <span>Customers</span>
        </Link>

        <div className="pt-4 mt-4 border-t border-slate-700">
          <Link
            to="/admin/settings"
            className={`flex items-center space-x-2 p-3 rounded-md transition-colors ${
              isActive('/admin/settings')
                ? 'bg-yellow-500 text-white'
                : 'text-gray-300 hover:bg-slate-700'
            }`}
          >
            <Settings size={20} />
            <span>Settings</span>
          </Link>
        </div>
      </nav>
    </div>
  );
};

export default AdminSidebar;