import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { logout } from '../store/slices/authSlice';
import { toggleMobileMenu, closeMobileMenu } from '../store/slices/uiSlice';
import { ShoppingCart, User, Menu, X, LogOut, Package } from 'lucide-react';

const Header: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useSelector((state: RootState) => state.auth);
  const { items } = useSelector((state: RootState) => state.cart);
  const { mobileMenuOpen } = useSelector((state: RootState) => state.ui);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };

  const handleMenuToggle = () => {
    dispatch(toggleMobileMenu());
  };

  const closeMenu = () => {
    dispatch(closeMobileMenu());
  };

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md' : 'bg-white'
      }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2" onClick={closeMenu}>
            <img src="/favicon.svg" alt="BundleStore Logo" className="h-10 w-10" />
            <span className="text-xl font-bold text-slate-800">BundleStore</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-slate-700 hover:text-yellow-500 transition-colors">
              Home
            </Link>
            <Link to="/product/mtn" className="text-slate-700 hover:text-yellow-500 transition-colors">
              MTN
            </Link>
            <Link to="/product/at-bigtime" className="text-slate-700 hover:text-yellow-500 transition-colors">
              AT BIGTIME
            </Link>
            <Link to="/product/at-ishare" className="text-slate-700 hover:text-yellow-500 transition-colors">
              AT iSHARE
            </Link>
            <Link to="/product/telecel" className="text-slate-700 hover:text-yellow-500 transition-colors">
              TELECEL
            </Link>
          </nav>

          {/* Desktop Right Menu */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/cart" className="relative p-2 text-slate-700 hover:text-yellow-500 transition-colors">
              <ShoppingCart size={24} />
              {items.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {items.reduce((total, item) => total + item.quantity, 0)}
                </span>
              )}
            </Link>

            {isAuthenticated ? (
              <div className="relative group">
                <button className="flex items-center space-x-1 text-slate-700 hover:text-yellow-500 transition-colors">
                  <User size={24} />
                  <span>{user?.name?.split(' ')[0]}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden z-20 hidden group-hover:block">
                  <div className="py-1">
                    <Link
                      to="/account"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-yellow-500 hover:text-white"
                    >
                      My Account
                    </Link>
                    {user?.role === 'admin' && (
                      <Link
                        to="/admin"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-yellow-500 hover:text-white"
                      >
                        Admin Dashboard
                      </Link>
                    )}
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-yellow-500 hover:text-white"
                    >
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <Link
                to="/login"
                className="btn btn-primary"
              >
                Login
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-slate-700 focus:outline-none"
            onClick={handleMenuToggle}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="container mx-auto px-4 py-2">
            <nav className="flex flex-col space-y-4 py-4">
              <Link
                to="/"
                className="text-slate-700 hover:text-yellow-500 transition-colors"
                onClick={closeMenu}
              >
                Home
              </Link>
              <Link
                to="/product/mtn"
                className="text-slate-700 hover:text-yellow-500 transition-colors"
                onClick={closeMenu}
              >
                MTN
              </Link>
              <Link
                to="/product/at-bigtime"
                className="text-slate-700 hover:text-yellow-500 transition-colors"
                onClick={closeMenu}
              >
                AT BIGTIME
              </Link>
              <Link
                to="/product/at-ishare"
                className="text-slate-700 hover:text-yellow-500 transition-colors"
                onClick={closeMenu}
              >
                AT iSHARE
              </Link>
              <Link
                to="/product/telecel"
                className="text-slate-700 hover:text-yellow-500 transition-colors"
                onClick={closeMenu}
              >
                TELECEL
              </Link>

              <div className="border-t border-gray-200 pt-4">
                <Link
                  to="/cart"
                  className="flex items-center space-x-2 text-slate-700 hover:text-yellow-500 transition-colors"
                  onClick={closeMenu}
                >
                  <ShoppingCart size={20} />
                  <span>Cart ({items.reduce((total, item) => total + item.quantity, 0)})</span>
                </Link>
              </div>

              {isAuthenticated ? (
                <>
                  <Link
                    to="/account"
                    className="flex items-center space-x-2 text-slate-700 hover:text-yellow-500 transition-colors"
                    onClick={closeMenu}
                  >
                    <User size={20} />
                    <span>My Account</span>
                  </Link>
                  {user?.role === 'admin' && (
                    <Link
                      to="/admin"
                      className="flex items-center space-x-2 text-slate-700 hover:text-yellow-500 transition-colors"
                      onClick={closeMenu}
                    >
                      <Package size={20} />
                      <span>Admin Dashboard</span>
                    </Link>
                  )}
                  <button
                    onClick={() => {
                      handleLogout();
                      closeMenu();
                    }}
                    className="flex items-center space-x-2 text-slate-700 hover:text-yellow-500 transition-colors"
                  >
                    <LogOut size={20} />
                    <span>Logout</span>
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  className="btn btn-primary w-full text-center"
                  onClick={closeMenu}
                >
                  Login
                </Link>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;