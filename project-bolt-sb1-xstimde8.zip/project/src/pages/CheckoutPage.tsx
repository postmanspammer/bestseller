import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Helmet } from 'react-helmet-async';
import { RootState } from '../store';
import { createOrderStart, createOrderSuccess } from '../store/slices/orderSlice';
import { clearCart } from '../store/slices/cartSlice';
import { showNotification } from '../store/slices/uiSlice';
import { CreditCard, CheckCircle, CreditCard as CreditCardIcon, Smartphone } from 'lucide-react';

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { items, totalAmount } = useSelector((state: RootState) => state.cart);
  const { user } = useSelector((state: RootState) => state.auth);

  const [email, setEmail] = useState(user?.email || '');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'moolre' | 'paystack'>('moolre');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isOrderComplete, setIsOrderComplete] = useState(false);

  if (items.length === 0 && !isOrderComplete) {
    navigate('/cart');
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !phoneNumber) {
      dispatch(
        showNotification({
          message: 'Please fill in all required fields',
          type: 'error',
        })
      );
      return;
    }

    setIsProcessing(true);
    dispatch(createOrderStart());

    // Simulate payment processing
    setTimeout(() => {
      const newOrder = {
        id: `order-${Date.now()}`,
        userId: user?.id || 'guest',
        items: [...items],
        totalAmount,
        status: 'processing' as const,
        paymentMethod,
        paymentStatus: 'paid' as const,
        shippingDetails: {
          email,
          phoneNumber,
        },
        createdAt: new Date().toISOString(),
      };

      dispatch(createOrderSuccess(newOrder));
      dispatch(clearCart());
      dispatch(
        showNotification({
          message: 'Order placed successfully!',
          type: 'success',
        })
      );

      setIsProcessing(false);
      setIsOrderComplete(true);
    }, 2000);
  };

  if (isOrderComplete) {
    return (
      <>
        <Helmet>
          <title>Order Confirmation - BundleStore</title>
        </Helmet>
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8 text-center">
            <div className="flex justify-center mb-6">
              <div className="bg-green-100 rounded-full p-3">
                <CheckCircle size={48} className="text-green-500" />
              </div>
            </div>
            <h1 className="text-3xl font-bold mb-4">Thank You for Your Order!</h1>
            <p className="text-gray-600 mb-6">
              Your order has been placed successfully. You will receive a confirmation email shortly.
            </p>
            <div className="mb-8 p-4 bg-gray-50 rounded-md">
              <p className="font-medium">Order Number: #{Date.now().toString().slice(-8)}</p>
              <p className="text-sm text-gray-500 mt-2">Your data bundle will be activated within 5 minutes.</p>
            </div>
            <button
              onClick={() => navigate('/')}
              className="btn btn-primary"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Checkout - BundleStore</title>
      </Helmet>
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Checkout Form */}
          <div className="lg:w-2/3">
            <form onSubmit={handleSubmit}>
              <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-semibold">Contact Information</h2>
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="input"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <div className="flex items-center">
                      <div className="flex-shrink-0 mr-2">
                        <Smartphone size={20} className="text-gray-400" />
                      </div>
                      <input
                        type="tel"
                        id="phone"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="input"
                        placeholder="Enter the number to receive the data bundle"
                        required
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      This is the number that will receive the data bundle
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-semibold">Payment Method</h2>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex flex-col space-y-3">
                    <label className="flex items-center p-4 border rounded-md cursor-pointer hover:border-yellow-500 transition-colors">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="moolre"
                        checked={paymentMethod === 'moolre'}
                        onChange={() => setPaymentMethod('moolre')}
                        className="mr-3"
                      />
                      <div className="flex items-center">
                        <div className="bg-blue-500 text-white p-2 rounded-md mr-3">
                          <CreditCardIcon size={20} />
                        </div>
                        <div>
                          <p className="font-medium">Moolre Payment</p>
                          <p className="text-sm text-gray-500">Fast and secure payment</p>
                        </div>
                      </div>
                    </label>

                    <label className="flex items-center p-4 border rounded-md cursor-pointer hover:border-yellow-500 transition-colors">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="paystack"
                        checked={paymentMethod === 'paystack'}
                        onChange={() => setPaymentMethod('paystack')}
                        className="mr-3"
                      />
                      <div className="flex items-center">
                        <div className="bg-green-500 text-white p-2 rounded-md mr-3">
                          <CreditCardIcon size={20} />
                        </div>
                        <div>
                          <p className="font-medium">Paystack</p>
                          <p className="text-sm text-gray-500">Pay with card or bank transfer</p>
                        </div>
                      </div>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="btn btn-primary px-8 py-3 flex items-center"
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <CreditCard size={20} className="mr-2" />
                      Complete Payment
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

              <div className="divide-y">
                {items.map((item) => (
                  <div key={`${item.id}-${item.size}`} className="py-3 flex justify-between">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-gray-500">
                        {item.size} × {item.quantity}
                      </p>
                    </div>
                    <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}
              </div>

              <div className="border-t mt-4 pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="font-medium">$0.00</span>
                </div>
                <div className="border-t pt-2 flex justify-between">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-xl">${totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CheckoutPage;