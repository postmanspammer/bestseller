import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Helmet } from 'react-helmet-async';
import { RootState } from '../store';
import { fetchProductsStart, fetchProductsSuccess } from '../store/slices/productSlice';
import ProductCard from '../components/ProductCard';
import { ArrowRight, Zap, Shield, Clock, CreditCard } from 'lucide-react';
import { Link } from 'react-router-dom';
import { showNotification } from '../store/slices/uiSlice';

// Mock data for initial display
const mockProducts = [
  {
    id: 'mtn',
    name: 'MTN Data Bundles',
    provider: 'MTN' as const,
    description: 'Fast and reliable internet connectivity with wide coverage across the country.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/mtn-logo.jpg',
    plans: [
      { size: '1GB', price: 5.99, validity: '30 days' },
      { size: '3GB', price: 12.99, validity: '30 days' },
      { size: '10GB', price: 29.99, validity: '30 days' },
      { size: '20GB', price: 49.99, validity: '30 days' },
      { size: '50GB', price: 99.99, validity: '30 days' },
      { size: '100GB', price: 149.99, validity: '30 days' },
    ],
    featured: true,
  },
  {
    id: 'at-bigtime',
    name: 'AT BIGTIME Bundles',
    provider: 'AT BIGTIME' as const,
    description: 'Affordable data packages with excellent urban coverage and streaming benefits.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/at-bigtime-logo.jpg',
    plans: [
      { size: '1GB', price: 4.99, validity: '30 days' },
      { size: '5GB', price: 19.99, validity: '30 days' },
      { size: '15GB', price: 39.99, validity: '30 days' },
      { size: '30GB', price: 69.99, validity: '30 days' },
      { size: '75GB', price: 119.99, validity: '30 days' },
      { size: '200GB', price: 199.99, validity: '30 days' },
    ],
    featured: true,
  },
  {
    id: 'at-ishare',
    name: 'AT iSHARE Bundles',
    provider: 'AT iSHARE' as const,
    description: 'Share your data with family and friends with these flexible data packages.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/at-ishare-logo.jpg',
    plans: [
      { size: '2GB', price: 8.99, validity: '30 days' },
      { size: '5GB', price: 17.99, validity: '30 days' },
      { size: '15GB', price: 34.99, validity: '30 days' },
      { size: '40GB', price: 79.99, validity: '30 days' },
      { size: '100GB', price: 139.99, validity: '30 days' },
      { size: '200GB', price: 219.99, validity: '30 days' },
    ],
    featured: false,
  },
  {
    id: 'telecel',
    name: 'TELECEL Data Bundles',
    provider: 'TELECEL' as const,
    description: 'Budget-friendly data options with good coverage in major cities and towns.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/telecel-logo.jpg',
    plans: [
      { size: '1GB', price: 3.99, validity: '30 days' },
      { size: '3GB', price: 9.99, validity: '30 days' },
      { size: '10GB', price: 24.99, validity: '30 days' },
      { size: '25GB', price: 54.99, validity: '30 days' },
      { size: '50GB', price: 89.99, validity: '30 days' },
      { size: '150GB', price: 179.99, validity: '30 days' },
    ],
    featured: false,
  },
];

const HomePage: React.FC = () => {
  const dispatch = useDispatch();
  const { products, loading } = useSelector((state: RootState) => state.products);

  useEffect(() => {
    // In a real app, this would be an API call
    dispatch(fetchProductsStart());
    
    // Simulate API call with mock data
    setTimeout(() => {
      dispatch(fetchProductsSuccess(mockProducts));
      
      // Show welcome notification
      dispatch(
        showNotification({
          message: 'Welcome to BundleStore! Browse our latest data bundle offers.',
          type: 'info',
        })
      );
    }, 1000);
  }, [dispatch]);

  const featuredProducts = products.filter(product => product.featured);

  return (
    <>
      <Helmet>
        <title>BundleStore - Buy Data Bundles Online</title>
        <meta name="description" content="Purchase data bundles from MTN, AT BIGTIME, AT iSHARE, and TELECEL with instant delivery" />
      </Helmet>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Fast and Reliable Data Bundles
              </h1>
              <p className="text-xl mb-6 text-gray-300">
                Get instant access to affordable data bundles from all major telecom providers.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/product/mtn" className="btn btn-primary">
                  Shop MTN Bundles
                </Link>
                <Link to="/product/telecel" className="btn btn-outline border-white text-white hover:bg-white hover:text-slate-900">
                  Explore All Providers
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="grid grid-cols-2 gap-4">
                {mockProducts.map((product) => (
                  <div key={product.id} className="bg-white p-4 rounded-lg shadow-md">
                    <img
                      src={product.logoUrl}
                      alt={`${product.name} logo`}
                      className="h-16 w-16 object-contain mx-auto mb-2"
                    />
                    <p className="text-slate-800 text-center font-medium">{product.name}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Featured Data Bundles</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our most popular data packages with the best value for your money.
            </p>
          </div>

          {loading ? (
            <div className="flex justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.length > 0 ? (
                featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))
              ) : (
                mockProducts
                  .filter((product) => product.featured)
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
              )}
            </div>
          )}

          <div className="text-center mt-10">
            <Link
              to="/"
              className="inline-flex items-center text-yellow-600 font-medium hover:text-yellow-700"
            >
              View All Data Bundles <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
        </div>
      </section>

      {/* All Providers */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">All Telecom Providers</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Choose from a wide range of data bundles from all major telecom providers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {loading ? (
              Array(4)
                .fill(0)
                .map((_, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-lg shadow-md p-6 animate-pulse"
                  >
                    <div className="h-24 w-24 bg-gray-200 rounded-full mx-auto mb-4"></div>
                    <div className="h-6 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto mb-4"></div>
                    <div className="h-10 bg-gray-200 rounded w-full"></div>
                  </div>
                ))
            ) : (
              products.length > 0
                ? products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
                : mockProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
            )}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-slate-800 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose BundleStore?</h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              We offer the best data bundle experience with instant delivery and excellent customer support.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="bg-yellow-500 rounded-full p-4 inline-block mb-4">
                <Zap size={24} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Instant Delivery</h3>
              <p className="text-gray-300">
                Get your data bundles delivered instantly to your phone after payment.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="bg-yellow-500 rounded-full p-4 inline-block mb-4">
                <Shield size={24} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure Payments</h3>
              <p className="text-gray-300">
                Your transactions are protected with industry-standard security measures.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="bg-yellow-500 rounded-full p-4 inline-block mb-4">
                <Clock size={24} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">24/7 Support</h3>
              <p className="text-gray-300">
                Our customer support team is available round the clock to assist you.
              </p>
            </div>

            <div className="text-center p-6">
              <div className="bg-yellow-500 rounded-full p-4 inline-block mb-4">
                <CreditCard size={24} className="text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Multiple Payment Options</h3>
              <p className="text-gray-300">
                Pay with Moolre, Paystack, or other convenient payment methods.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-yellow-500">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4 text-white">Ready to Get Started?</h2>
          <p className="text-xl mb-8 text-white">
            Browse our data bundles and find the perfect plan for your needs.
          </p>
          <Link
            to="/product/mtn"
            className="btn bg-white text-yellow-600 hover:bg-gray-100 font-bold px-8 py-3 rounded-md"
          >
            Shop Now
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;