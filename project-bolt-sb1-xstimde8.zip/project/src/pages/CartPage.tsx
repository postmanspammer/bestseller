import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Helmet } from 'react-helmet-async';
import { RootState } from '../store';
import { removeFromCart, updateQuantity, clearCart } from '../store/slices/cartSlice';
import { showNotification } from '../store/slices/uiSlice';
import { Trash2, ShoppingBag, ArrowLeft, ShoppingCart } from 'lucide-react';

const CartPage: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { items, totalAmount } = useSelector((state: RootState) => state.cart);

  const handleRemoveItem = (id: string, size: string) => {
    dispatch(removeFromCart({ id, size }));
    dispatch(
      showNotification({
        message: 'Item removed from cart',
        type: 'info',
      })
    );
  };

  const handleUpdateQuantity = (id: string, size: string, quantity: number) => {
    if (quantity < 1) return;
    dispatch(updateQuantity({ id, size, quantity }));
  };

  const handleClearCart = () => {
    dispatch(clearCart());
    dispatch(
      showNotification({
        message: 'Cart cleared',
        type: 'info',
      })
    );
  };

  const handleCheckout = () => {
    navigate('/checkout');
  };

  if (items.length === 0) {
    return (
      <>
        <Helmet>
          <title>Your Cart - BundleStore</title>
        </Helmet>
        <div className="container mx-auto px-4 py-16">
          <h1 className="text-3xl font-bold mb-8">Your Cart</h1>
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="flex justify-center mb-4">
              <ShoppingCart size={64} className="text-gray-300" />
            </div>
            <h2 className="text-2xl font-semibold mb-4">Your cart is empty</h2>
            <p className="text-gray-600 mb-8">
              Looks like you haven't added any data bundles to your cart yet.
            </p>
            <Link to="/" className="btn btn-primary">
              Browse Data Bundles
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Your Cart - BundleStore</title>
      </Helmet>
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-3xl font-bold mb-8">Your Cart</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items */}
          <div className="lg:w-2/3">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 border-b">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">
                    Cart Items ({items.reduce((total, item) => total + item.quantity, 0)})
                  </h2>
                  <button
                    onClick={handleClearCart}
                    className="text-red-500 hover:text-red-700 flex items-center"
                  >
                    <Trash2 size={16} className="mr-1" />
                    Clear Cart
                  </button>
                </div>
              </div>

              <div className="divide-y">
                {items.map((item) => (
                  <div key={`${item.id}-${item.size}`} className="p-6 flex flex-col sm:flex-row">
                    <div className="sm:w-1/4 mb-4 sm:mb-0">
                      <h3 className="font-semibold">{item.name}</h3>
                      <p className="text-gray-600 text-sm">{item.provider}</p>
                      <p className="text-gray-600 text-sm">Size: {item.size}</p>
                    </div>

                    <div className="sm:w-1/4 flex items-center mb-4 sm:mb-0">
                      <div className="flex items-center">
                        <button
                          className="border border-gray-300 rounded-l-md px-3 py-1 hover:bg-gray-100"
                          onClick={() =>
                            handleUpdateQuantity(item.id, item.size, item.quantity - 1)
                          }
                        >
                          -
                        </button>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) =>
                            handleUpdateQuantity(
                              item.id,
                              item.size,
                              parseInt(e.target.value) || 1
                            )
                          }
                          className="border-t border-b border-gray-300 px-3 py-1 w-12 text-center"
                        />
                        <button
                          className="border border-gray-300 rounded-r-md px-3 py-1 hover:bg-gray-100"
                          onClick={() =>
                            handleUpdateQuantity(item.id, item.size, item.quantity + 1)
                          }
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="sm:w-1/4 flex items-center justify-center mb-4 sm:mb-0">
                      <p className="font-medium">${item.price.toFixed(2)} each</p>
                    </div>

                    <div className="sm:w-1/4 flex items-center justify-between">
                      <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                      <button
                        onClick={() => handleRemoveItem(item.id, item.size)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <Link
                to="/"
                className="inline-flex items-center text-slate-700 hover:text-yellow-600"
              >
                <ArrowLeft size={16} className="mr-2" />
                Continue Shopping
              </Link>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="font-medium">$0.00</span>
                </div>
                <div className="border-t pt-4 flex justify-between">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-xl">${totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={handleCheckout}
                className="btn btn-primary w-full flex items-center justify-center"
              >
                <ShoppingBag size={18} className="mr-2" />
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CartPage;