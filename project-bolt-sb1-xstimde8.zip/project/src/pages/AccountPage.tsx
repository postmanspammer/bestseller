import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../store';
import { updateUserProfile } from '../store/slices/authSlice';
import { fetchOrdersSuccess } from '../store/slices/orderSlice';
import { showNotification } from '../store/slices/uiSlice';
import { User, Mail, Phone, Package, Clock, CreditCard } from 'lucide-react';

const AccountPage: React.FC = () => {
  const dispatch = useDispatch();
  const { user } = useSelector((state: RootState) => state.auth);
  const { orders } = useSelector((state: RootState) => state.orders);

  const [activeTab, setActiveTab] = useState('profile');
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Simulate fetching orders
    setTimeout(() => {
      // Mock orders data
      const mockOrders = [
        {
          id: 'order-1',
          userId: user?.id || '',
          items: [
            {
              id: 'mtn',
              name: 'MTN Data Bundles',
              provider: 'MTN',
              size: '10GB',
              price: 29.99,
              quantity: 1,
            },
          ],
          totalAmount: 29.99,
          status: 'completed' as const,
          paymentMethod: 'moolre' as const,
          paymentStatus: 'paid' as const,
          shippingDetails: {
            email: user?.email || '',
            phoneNumber: '1234567890',
          },
          createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
        },
        {
          id: 'order-2',
          userId: user?.id || '',
          items: [
            {
              id: 'at-bigtime',
              name: 'AT BIGTIME Bundles',
              provider: 'AT BIGTIME',
              size: '5GB',
              price: 19.99,
              quantity: 1,
            },
          ],
          totalAmount: 19.99,
          status: 'completed' as const,
          paymentMethod: 'paystack' as const,
          paymentStatus: 'paid' as const,
          shippingDetails: {
            email: user?.email || '',
            phoneNumber: '1234567890',
          },
          createdAt: new Date(Date.now() - 86400000 * 7).toISOString(), // 7 days ago
        },
      ];

      dispatch(fetchOrdersSuccess(mockOrders));
    }, 1000);
  }, [dispatch, user]);

  const handleSaveProfile = () => {
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      dispatch(
        updateUserProfile({
          name,
          email,
        })
      );

      dispatch(
        showNotification({
          message: 'Profile updated successfully',
          type: 'success',
        })
      );

      setIsLoading(false);
      setIsEditing(false);
    }, 1000);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <>
      <Helmet>
        <title>My Account - BundleStore</title>
      </Helmet>
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-3xl font-bold mb-8">My Account</h1>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="md:w-1/4">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6 bg-slate-800 text-white">
                <div className="flex items-center space-x-3">
                  <div className="bg-yellow-500 rounded-full p-2">
                    <User size={24} className="text-white" />
                  </div>
                  <div>
                    <h2 className="font-semibold">{user?.name}</h2>
                    <p className="text-sm text-gray-300">{user?.email}</p>
                  </div>
                </div>
              </div>

              <nav className="p-4">
                <ul className="space-y-1">
                  <li>
                    <button
                      onClick={() => setActiveTab('profile')}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center space-x-2 ${
                        activeTab === 'profile'
                          ? 'bg-yellow-500 text-white'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      <User size={18} />
                      <span>Profile</span>
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => setActiveTab('orders')}
                      className={`w-full text-left px-4 py-2 rounded-md flex items-center space-x-2 ${
                        activeTab === 'orders'
                          ? 'bg-yellow-500 text-white'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      <Package size={18} />
                      <span>Orders</span>
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:w-3/4">
            {activeTab === 'profile' && (
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6 border-b flex justify-between items-center">
                  <h2 className="text-xl font-semibold">Profile Information</h2>
                  {!isEditing ? (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-yellow-600 hover:text-yellow-700 font-medium"
                    >
                      Edit
                    </button>
                  ) : (
                    <button
                      onClick={() => setIsEditing(false)}
                      className="text-gray-600 hover:text-gray-700 font-medium"
                    >
                      Cancel
                    </button>
                  )}
                </div>

                <div className="p-6">
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                          Full Name
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <User size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="input pl-10"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                          Email Address
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Mail size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="input pl-10"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                          Phone Number
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Phone size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="tel"
                            id="phone"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            className="input pl-10"
                          />
                        </div>
                      </div>

                      <div className="pt-4">
                        <button
                          onClick={handleSaveProfile}
                          className="btn btn-primary"
                          disabled={isLoading}
                        >
                          {isLoading ? (
                            <>
                              <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></div>
                              Saving...
                            </>
                          ) : (
                            'Save Changes'
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="flex items-center">
                        <User size={20} className="text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm text-gray-500">Full Name</p>
                          <p className="font-medium">{user?.name}</p>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <Mail size={20} className="text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm text-gray-500">Email Address</p>
                          <p className="font-medium">{user?.email}</p>
                        </div>
                      </div>

                      <div className="flex items-center">
                        <Phone size={20} className="text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm text-gray-500">Phone Number</p>
                          <p className="font-medium">{phoneNumber || 'Not set'}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'orders' && (
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6 border-b">
                  <h2 className="text-xl font-semibold">Order History</h2>
                </div>

                {orders.length === 0 ? (
                  <div className="p-6 text-center">
                    <Package size={48} className="text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No orders yet</h3>
                    <p className="text-gray-500 mb-4">
                      You haven't placed any orders yet.
                    </p>
                    <a href="/" className="btn btn-primary">
                      Browse Data Bundles
                    </a>
                  </div>
                ) : (
                  <div className="divide-y">
                    {orders.map((order) => (
                      <div key={order.id} className="p-6">
                        <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                          <div>
                            <p className="font-medium">Order #{order.id.split('-')[1]}</p>
                            <div className="flex items-center text-sm text-gray-500">
                              <Clock size={14} className="mr-1" />
                              <span>{formatDate(order.createdAt)}</span>
                            </div>
                          </div>
                          <div className="mt-2 md:mt-0">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              order.status === 'completed'
                                ? 'bg-green-100 text-green-800'
                                : order.status === 'processing'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </span>
                          </div>
                        </div>

                        <div className="space-y-3">
                          {order.items.map((item) => (
                            <div key={`${item.id}-${item.size}`} className="flex justify-between">
                              <div>
                                <p className="font-medium">{item.name}</p>
                                <p className="text-sm text-gray-500">
                                  {item.size} × {item.quantity}
                                </p>
                              </div>
                              <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                            </div>
                          ))}
                        </div>

                        <div className="flex justify-between items-center mt-4 pt-4 border-t">
                          <div className="flex items-center text-sm">
                            <CreditCard size={16} className="mr-1 text-gray-500" />
                            <span className="text-gray-500">
                              Paid with {order.paymentMethod.charAt(0).toUpperCase() + order.paymentMethod.slice(1)}
                            </span>
                          </div>
                          <p className="font-bold">${order.totalAmount.toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default AccountPage;