import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { Helmet } from 'react-helmet-async';
import { RootState } from '../store';
import { selectProduct } from '../store/slices/productSlice';
import { addToCart } from '../store/slices/cartSlice';
import { showNotification } from '../store/slices/uiSlice';
import { Check, ShoppingCart } from 'lucide-react';

// Mock data for initial display
const mockProducts = [
  {
    id: 'mtn',
    name: 'MTN Data Bundles',
    provider: 'MTN' as const,
    description: 'Fast and reliable internet connectivity with wide coverage across the country.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/mtn-logo.jpg',
    plans: [
      { size: '1GB', price: 5.99, validity: '30 days' },
      { size: '3GB', price: 12.99, validity: '30 days' },
      { size: '10GB', price: 29.99, validity: '30 days' },
      { size: '20GB', price: 49.99, validity: '30 days' },
      { size: '50GB', price: 99.99, validity: '30 days' },
      { size: '100GB', price: 149.99, validity: '30 days' },
    ],
    featured: true,
  },
  {
    id: 'at-bigtime',
    name: 'AT BIGTIME Bundles',
    provider: 'AT BIGTIME' as const,
    description: 'Affordable data packages with excellent urban coverage and streaming benefits.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/at-bigtime-logo.jpg',
    plans: [
      { size: '1GB', price: 4.99, validity: '30 days' },
      { size: '5GB', price: 19.99, validity: '30 days' },
      { size: '15GB', price: 39.99, validity: '30 days' },
      { size: '30GB', price: 69.99, validity: '30 days' },
      { size: '75GB', price: 119.99, validity: '30 days' },
      { size: '200GB', price: 199.99, validity: '30 days' },
    ],
    featured: true,
  },
  {
    id: 'at-ishare',
    name: 'AT iSHARE Bundles',
    provider: 'AT iSHARE' as const,
    description: 'Share your data with family and friends with these flexible data packages.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/at-ishare-logo.jpg',
    plans: [
      { size: '2GB', price: 8.99, validity: '30 days' },
      { size: '5GB', price: 17.99, validity: '30 days' },
      { size: '15GB', price: 34.99, validity: '30 days' },
      { size: '40GB', price: 79.99, validity: '30 days' },
      { size: '100GB', price: 139.99, validity: '30 days' },
      { size: '200GB', price: 219.99, validity: '30 days' },
    ],
    featured: false,
  },
  {
    id: 'telecel',
    name: 'TELECEL Data Bundles',
    provider: 'TELECEL' as const,
    description: 'Budget-friendly data options with good coverage in major cities and towns.',
    logoUrl: 'https://i.ibb.co/Qp1nCKJ/telecel-logo.jpg',
    plans: [
      { size: '1GB', price: 3.99, validity: '30 days' },
      { size: '3GB', price: 9.99, validity: '30 days' },
      { size: '10GB', price: 24.99, validity: '30 days' },
      { size: '25GB', price: 54.99, validity: '30 days' },
      { size: '50GB', price: 89.99, validity: '30 days' },
      { size: '150GB', price: 179.99, validity: '30 days' },
    ],
    featured: false,
  },
];

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { selectedProduct, loading } = useSelector((state: RootState) => state.products);
  
  const [selectedPlan, setSelectedPlan] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);

  useEffect(() => {
    if (id) {
      // In a real app, this would fetch from an API
      const product = mockProducts.find(p => p.id === id);
      if (product) {
        dispatch(selectProduct(product.id));
      } else {
        navigate('/not-found');
      }
    }
  }, [id, dispatch, navigate]);

  const handleAddToCart = () => {
    if (!selectedProduct || !selectedPlan) {
      dispatch(
        showNotification({
          message: 'Please select a data plan',
          type: 'warning',
        })
      );
      return;
    }

    const plan = selectedProduct.plans.find(p => p.size === selectedPlan);
    if (!plan) return;

    dispatch(
      addToCart({
        id: selectedProduct.id,
        name: selectedProduct.name,
        provider: selectedProduct.provider,
        size: selectedPlan,
        price: plan.price,
        quantity,
      })
    );

    dispatch(
      showNotification({
        message: `${selectedPlan} ${selectedProduct.name} added to cart`,
        type: 'success',
      })
    );
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/checkout');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    );
  }

  if (!selectedProduct) {
    const mockProduct = mockProducts.find(p => p.id === id);
    if (!mockProduct) {
      return (
        <div className="container mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Product not found</h2>
          <button
            onClick={() => navigate('/')}
            className="btn btn-primary"
          >
            Back to Home
          </button>
        </div>
      );
    }
    
    // Use mock data if product not in state
    return renderProductDetails(mockProduct);
  }

  return renderProductDetails(selectedProduct);

  function renderProductDetails(product: typeof selectedProduct) {
    if (!product) return null;
    
    return (
      <>
        <Helmet>
          <title>{product.name} - BundleStore</title>
          <meta name="description" content={product.description} />
        </Helmet>

        <div className="container mx-auto px-4 py-12">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="md:flex">
              {/* Product Image/Logo */}
              <div className="md:w-1/3 bg-gray-50 p-8 flex items-center justify-center">
                <img
                  src={product.logoUrl}
                  alt={`${product.name} logo`}
                  className="h-48 w-48 object-contain"
                />
              </div>

              {/* Product Details */}
              <div className="md:w-2/3 p-8">
                <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
                <p className="text-gray-600 mb-6">{product.description}</p>

                {/* Plan Selection */}
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-3">Select Data Plan</h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {product.plans.map((plan) => (
                      <button
                        key={plan.size}
                        className={`border rounded-md p-3 text-center transition-colors ${
                          selectedPlan === plan.size
                            ? 'border-yellow-500 bg-yellow-50 text-yellow-700'
                            : 'border-gray-300 hover:border-yellow-300'
                        }`}
                        onClick={() => setSelectedPlan(plan.size)}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-bold">{plan.size}</span>
                          {selectedPlan === plan.size && (
                            <Check size={16} className="text-yellow-500" />
                          )}
                        </div>
                        <div className="text-lg font-semibold">${plan.price.toFixed(2)}</div>
                        <div className="text-xs text-gray-500">{plan.validity}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quantity */}
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-3">Quantity</h2>
                  <div className="flex items-center">
                    <button
                      className="border border-gray-300 rounded-l-md px-4 py-2 hover:bg-gray-100"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    >
                      -
                    </button>
                    <input
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="border-t border-b border-gray-300 px-4 py-2 w-16 text-center"
                    />
                    <button
                      className="border border-gray-300 rounded-r-md px-4 py-2 hover:bg-gray-100"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Price */}
                {selectedPlan && (
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold mb-1">Total Price</h2>
                    <div className="text-3xl font-bold text-yellow-600">
                      $
                      {(
                        (product.plans.find((p) => p.size === selectedPlan)?.price || 0) * quantity
                      ).toFixed(2)}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                  <button
                    onClick={handleAddToCart}
                    className="btn btn-outline flex items-center justify-center"
                    disabled={!selectedPlan}
                  >
                    <ShoppingCart size={20} className="mr-2" />
                    Add to Cart
                  </button>
                  <button
                    onClick={handleBuyNow}
                    className="btn btn-primary"
                    disabled={!selectedPlan}
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Information */}
          <div className="mt-12 bg-white rounded-lg shadow-md overflow-hidden">
            <div className="border-b">
              <div className="px-6 py-4">
                <h2 className="text-xl font-semibold">Product Information</h2>
              </div>
            </div>
            <div className="p-6">
              <div className="mb-6">
                <h3 className="font-semibold mb-2">Provider</h3>
                <p>{product.provider}</p>
              </div>
              <div className="mb-6">
                <h3 className="font-semibold mb-2">Validity</h3>
                <p>All plans are valid for 30 days from activation</p>
              </div>
              <div className="mb-6">
                <h3 className="font-semibold mb-2">Activation</h3>
                <p>Data bundles are activated immediately after successful payment</p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Refund Policy</h3>
                <p>We do not offer refunds for activated data bundles</p>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
};

export default ProductPage;