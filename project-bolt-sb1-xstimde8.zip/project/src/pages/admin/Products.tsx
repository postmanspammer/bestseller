import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import { addProduct, updateProduct, deleteProduct } from '../../store/slices/productSlice';
import { showNotification } from '../../store/slices/uiSlice';
import { Plus, Edit, Trash2, X, Check } from 'lucide-react';

const AdminProducts: React.FC = () => {
  const dispatch = useDispatch();
  const { products, loading } = useSelector((state: RootState) => state.products);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  useEffect(() => {
    // Simulate loading products
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleEditProduct = (product: any) => {
    setEditingProduct({
      ...product,
      plans: [...product.plans],
    });
    setIsEditing(true);
  };

  const handleAddNewProduct = () => {
    setEditingProduct({
      id: '',
      name: '',
      provider: 'MTN',
      description: '',
      logoUrl: '',
      plans: [
        { size: '1GB', price: 0, validity: '30 days' },
      ],
      featured: false,
    });
    setIsEditing(true);
  };

  const handleSaveProduct = () => {
    if (!editingProduct.id) {
      // Generate a new ID for new products
      const newProduct = {
        ...editingProduct,
        id: editingProduct.name.toLowerCase().replace(/\s+/g, '-'),
      };
      dispatch(addProduct(newProduct));
      dispatch(
        showNotification({
          message: 'Product added successfully',
          type: 'success',
        })
      );
    } else {
      dispatch(updateProduct(editingProduct));
      dispatch(
        showNotification({
          message: 'Product updated successfully',
          type: 'success',
        })
      );
    }
    setIsEditing(false);
    setEditingProduct(null);
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      dispatch(deleteProduct(id));
      dispatch(
        showNotification({
          message: 'Product deleted successfully',
          type: 'success',
        })
      );
    }
  };

  const handleAddPlan = () => {
    setEditingProduct({
      ...editingProduct,
      plans: [
        ...editingProduct.plans,
        { size: '', price: 0, validity: '30 days' },
      ],
    });
  };

  const handleRemovePlan = (index: number) => {
    const newPlans = [...editingProduct.plans];
    newPlans.splice(index, 1);
    setEditingProduct({
      ...editingProduct,
      plans: newPlans,
    });
  };

  const handlePlanChange = (index: number, field: string, value: any) => {
    const newPlans = [...editingProduct.plans];
    newPlans[index] = {
      ...newPlans[index],
      [field]: field === 'price' ? parseFloat(value) : value,
    };
    setEditingProduct({
      ...editingProduct,
      plans: newPlans,
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    );
  }

  if (isEditing) {
    return (
      <>
        <Helmet>
          <title>{editingProduct.id ? 'Edit' : 'Add'} Product - BundleStore Admin</title>
        </Helmet>
        <div>
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-2xl font-bold">{editingProduct.id ? 'Edit' : 'Add'} Product</h1>
            <button
              onClick={() => {
                setIsEditing(false);
                setEditingProduct(null);
              }}
              className="text-gray-600 hover:text-gray-800"
            >
              <X size={24} />
            </button>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product Name
                </label>
                <input
                  type="text"
                  value={editingProduct.name}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  className="input"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Provider
                </label>
                <select
                  value={editingProduct.provider}
                  onChange={(e) => setEditingProduct({ ...editingProduct, provider: e.target.value })}
                  className="select"
                >
                  <option value="MTN">MTN</option>
                  <option value="AT BIGTIME">AT BIGTIME</option>
                  <option value="AT iSHARE">AT iSHARE</option>
                  <option value="TELECEL">TELECEL</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="input h-24"
                ></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Logo URL
                </label>
                <input
                  type="text"
                  value={editingProduct.logoUrl}
                  onChange={(e) => setEditingProduct({ ...editingProduct, logoUrl: e.target.value })}
                  className="input"
                />
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="featured"
                  checked={editingProduct.featured}
                  onChange={(e) => setEditingProduct({ ...editingProduct, featured: e.target.checked })}
                  className="h-4 w-4 text-yellow-600 focus:ring-yellow-500 border-gray-300 rounded"
                />
                <label htmlFor="featured" className="ml-2 block text-sm text-gray-900">
                  Featured Product
                </label>
              </div>
            </div>

            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">Data Plans</h3>
                <button
                  onClick={handleAddPlan}
                  className="btn btn-outline flex items-center text-sm px-3 py-1"
                >
                  <Plus size={16} className="mr-1" />
                  Add Plan
                </button>
              </div>

              <div className="bg-gray-50 p-4 rounded-md">
                {editingProduct.plans.map((plan: any, index: number) => (
                  <div key={index} className="flex flex-wrap items-center mb-4 pb-4 border-b last:border-0 last:mb-0 last:pb-0">
                    <div className="w-full md:w-1/4 mb-2 md:mb-0 md:pr-2">
                      <label className="block text-xs font-medium text-gray-700 mb-1">
                        Size
                      </label>
                      <input
                        type="text"
                        value={plan.size}
                        onChange={(e) => handlePlanChange(index, 'size', e.target.value)}
                        className="input"
                        placeholder="e.g. 1GB"
                      />
                    </div>
                    <div className="w-full md:w-1/4 mb-2 md:mb-0 md:px-2">
                      <label className="block text-xs font-medium text-gray-700 mb-1">
                        Price ($)
                      </label>
                      <input
                        type="number"
                        value={plan.price}
                        onChange={(e) => handlePlanChange(index, 'price', e.target.value)}
                        className="input"
                        step="0.01"
                        min="0"
                      />
                    </div>
                    <div className="w-full md:w-1/4 mb-2 md:mb-0 md:px-2">
                      <label className="block text-xs font-medium text-gray-700 mb-1">
                        Validity
                      </label>
                      <input
                        type="text"
                        value={plan.validity}
                        onChange={(e) => handlePlanChange(index, 'validity', e.target.value)}
                        className="input"
                        placeholder="e.g. 30 days"
                      />
                    </div>
                    <div className="w-full md:w-1/4 flex justify-end md:pl-2">
                      <button
                        onClick={() => handleRemovePlan(index)}
                        className="text-red-500 hover:text-red-700"
                        disabled={editingProduct.plans.length <= 1}
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  setIsEditing(false);
                  setEditingProduct(null);
                }}
                className="btn btn-outline mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveProduct}
                className="btn btn-primary flex items-center"
              >
                <Check size={18} className="mr-2" />
                Save Product
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Products - BundleStore Admin</title>
      </Helmet>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Products</h1>
          <button
            onClick={handleAddNewProduct}
            className="btn btn-primary flex items-center"
          >
            <Plus size={18} className="mr-2" />
            Add Product
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Product
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Provider
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Plans
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Featured
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {products.map((product) => (
                  <tr key={product.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img
                            className="h-10 w-10 rounded-full object-cover"
                            src={product.logoUrl}
                            alt={product.name}
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{product.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{product.provider}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{product.plans.length} plans</div>
                      <div className="text-xs text-gray-400">
                        {product.plans[0].size} - {product.plans[product.plans.length - 1].size}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {product.featured ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          Yes
                        </span>
                      ) : (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                          No
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleEditProduct(product)}
                        className="text-yellow-600 hover:text-yellow-900 mr-3"
                      >
                        <Edit size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(product.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminProducts;