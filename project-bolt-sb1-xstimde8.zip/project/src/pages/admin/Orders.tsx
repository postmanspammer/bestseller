import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useDispatch } from 'react-redux';
import { updateOrderStatus, updatePaymentStatus } from '../../store/slices/orderSlice';
import { showNotification } from '../../store/slices/uiSlice';
import { Search, Filter, Eye, CheckCircle, XCircle, Clock } from 'lucide-react';

// Mock orders data
const mockOrders = [
  {
    id: 'order-1',
    customer: {
      name: 'John Doe',
      email: 'john@example.com',
      phone: '1234567890',
    },
    items: [
      {
        id: 'mtn',
        name: 'MTN Data Bundles',
        provider: 'MTN',
        size: '10GB',
        price: 29.99,
        quantity: 1,
      },
    ],
    totalAmount: 29.99,
    status: 'completed',
    paymentMethod: 'moolre',
    paymentStatus: 'paid',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
  },
  {
    id: 'order-2',
    customer: {
      name: 'Jane Smith',
      email: 'jane@example.com',
      phone: '9876543210',
    },
    items: [
      {
        id: 'at-bigtime',
        name: 'AT BIGTIME Bundles',
        provider: 'AT BIGTIME',
        size: '5GB',
        price: 19.99,
        quantity: 1,
      },
    ],
    totalAmount: 19.99,
    status: 'processing',
    paymentMethod: 'paystack',
    paymentStatus: 'paid',
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(), // 1 day ago
  },
  {
    id: 'order-3',
    customer: {
      name: 'Robert Johnson',
      email: 'robert@example.com',
      phone: '5551234567',
    },
    items: [
      {
        id: 'telecel',
        name: 'TELECEL Data Bundles',
        provider: 'TELECEL',
        size: '3GB',
        price: 9.99,
        quantity: 2,
      },
    ],
    totalAmount: 19.98,
    status: 'pending',
    paymentMethod: 'moolre',
    paymentStatus: 'pending',
    createdAt: new Date().toISOString(), // Today
  },
  {
    id: 'order-4',
    customer: {
      name: 'Emily Davis',
      email: 'emily@example.com',
      phone: '7778889999',
    },
    items: [
      {
        id: 'at-ishare',
        name: 'AT iSHARE Bundles',
        provider: 'AT iSHARE',
        size: '15GB',
        price: 34.99,
        quantity: 1,
      },
    ],
    totalAmount: 34.99,
    status: 'completed',
    paymentMethod: 'paystack',
    paymentStatus: 'paid',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(), // 3 days ago
  },
  {
    id: 'order-5',
    customer: {
      name: 'Michael Wilson',
      email: 'michael@example.com',
      phone: '3334445555',
    },
    items: [
      {
        id: 'mtn',
        name: 'MTN Data Bundles',
        provider: 'MTN',
        size: '20GB',
        price: 49.99,
        quantity: 1,
      },
    ],
    totalAmount: 49.99,
    status: 'cancelled',
    paymentMethod: 'moolre',
    paymentStatus: 'failed',
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(), // 4 days ago
  },
];

const AdminOrders: React.FC = () => {
  const dispatch = useDispatch();
  const [orders, setOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [viewingOrder, setViewingOrder] = useState<any>(null);

  useEffect(() => {
    // Simulate loading orders
    setTimeout(() => {
      setOrders(mockOrders);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleUpdateOrderStatus = (orderId: string, status: string) => {
    // Update local state
    setOrders(
      orders.map((order) =>
        order.id === orderId ? { ...order, status } : order
      )
    );

    // Update Redux store
    dispatch(
      updateOrderStatus({
        orderId,
        status: status as any,
      })
    );

    dispatch(
      showNotification({
        message: `Order status updated to ${status}`,
        type: 'success',
      })
    );

    // Close modal if open
    if (viewingOrder && viewingOrder.id === orderId) {
      setViewingOrder({ ...viewingOrder, status });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.phone.includes(searchTerm);

    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Orders - BundleStore Admin</title>
      </Helmet>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Orders</h1>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="relative flex-grow max-w-md">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-10"
              />
            </div>
            <div className="flex items-center">
              <Filter size={18} className="text-gray-400 mr-2" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="select"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="processing">Processing</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
        </div>

        {/* Orders Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Order ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                      No orders found
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((order) => (
                    <tr key={order.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        #{order.id.split('-')[1]}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{order.customer.name}</div>
                        <div className="text-sm text-gray-500">{order.customer.email}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${order.totalAmount.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          order.status === 'completed'
                            ? 'bg-green-100 text-green-800'
                            : order.status === 'processing'
                            ? 'bg-blue-100 text-blue-800'
                            : order.status === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(order.createdAt)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => setViewingOrder(order)}
                          className="text-yellow-600 hover:text-yellow-900"
                        >
                          <Eye size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Order Details Modal */}
        {viewingOrder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b flex justify-between items-center">
                <h2 className="text-xl font-semibold">
                  Order #{viewingOrder.id.split('-')[1]}
                </h2>
                <button
                  onClick={() => setViewingOrder(null)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  <XCircle size={24} />
                </button>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Customer Information</h3>
                    <p className="font-medium">{viewingOrder.customer.name}</p>
                    <p className="text-gray-600">{viewingOrder.customer.email}</p>
                    <p className="text-gray-600">{viewingOrder.customer.phone}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Order Information</h3>
                    <p className="text-gray-600">
                      <span className="font-medium">Date:</span> {formatDate(viewingOrder.createdAt)}
                    </p>
                    <p className="text-gray-600">
                      <span className="font-medium">Payment Method:</span>{' '}
                      {viewingOrder.paymentMethod.charAt(0).toUpperCase() + viewingOrder.paymentMethod.slice(1)}
                    </p>
                    <p className="text-gray-600">
                      <span className="font-medium">Payment Status:</span>{' '}
                      <span className={
                        viewingOrder.paymentStatus === 'paid'
                          ? 'text-green-600'
                          : viewingOrder.paymentStatus === 'pending'
                          ? 'text-yellow-600'
                          : 'text-red-600'
                      }>
                        {viewingOrder.paymentStatus.charAt(0).toUpperCase() + viewingOrder.paymentStatus.slice(1)}
                      </span>
                    </p>
                  </div>
                </div>

                <h3 className="text-sm font-medium text-gray-500 mb-2">Order Items</h3>
                <div className="bg-gray-50 rounded-md p-4 mb-6">
                  {viewingOrder.items.map((item: any, index: number) => (
                    <div key={index} className="flex justify-between py-2 border-b last:border-0 last:pb-0 first:pt-0">
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm text-gray-600">
                          {item.size} × {item.quantity}
                        </p>
                      </div>
                      <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                  <div className="flex justify-between pt-4 font-bold">
                    <p>Total</p>
                    <p>${viewingOrder.totalAmount.toFixed(2)}</p>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Order Status</h3>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleUpdateOrderStatus(viewingOrder.id, 'pending')}
                      className={`px-3 py-1 rounded-md text-sm font-medium ${
                        viewingOrder.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                    >
                      <Clock size={14} className="inline mr-1" />
                      Pending
                    </button>
                    <button
                      onClick={() => handleUpdateOrderStatus(viewingOrder.id, 'processing')}
                      className={`px-3 py-1 rounded-md text-sm font-medium ${
                        viewingOrder.status === 'processing'
                          ? 'bg-blue-100 text-blue-800 border border-blue-300'
                          : 'bg-gray-100 text -gray-800 hover:bg-gray-200'
                      }`}
                    >
                      <Clock size={14} className="inline mr-1" />
                      Processing
                    </button>
                    <button
                      onClick={() => handleUpdateOrderStatus(viewingOrder.id, 'completed')}
                      className={`px-3 py-1 rounded-md text-sm font-medium ${
                        viewingOrder.status === 'completed'
                          ? 'bg-green-100 text-green-800 border border-green-300'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                    >
                      <CheckCircle size={14} className="inline mr-1" />
                      Completed
                    </button>
                    <button
                      onClick={() => handleUpdateOrderStatus(viewingOrder.id, 'cancelled')}
                      className={`px-3 py-1 rounded-md text-sm font-medium ${
                        viewingOrder.status === 'cancelled'
                          ? 'bg-red-100 text-red-800 border border-red-300'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                    >
                      <XCircle size={14} className="inline mr-1" />
                      Cancelled
                    </button>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={() => setViewingOrder(null)}
                    className="btn btn-primary"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default AdminOrders;