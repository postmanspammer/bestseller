import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Search, Mail, Phone, User, ShoppingBag } from 'lucide-react';

// Mock customers data
const mockCustomers = [
  {
    id: 'user-1',
    name: 'John Doe',
    email: 'john@example.com',
    phone: '1234567890',
    totalOrders: 5,
    totalSpent: 149.95,
    createdAt: new Date(Date.now() - 86400000 * 30).toISOString(), // 30 days ago
  },
  {
    id: 'user-2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    phone: '9876543210',
    totalOrders: 3,
    totalSpent: 89.97,
    createdAt: new Date(Date.now() - 86400000 * 45).toISOString(), // 45 days ago
  },
  {
    id: 'user-3',
    name: 'Robert Johnson',
    email: 'robert@example.com',
    phone: '5551234567',
    totalOrders: 2,
    totalSpent: 59.98,
    createdAt: new Date(Date.now() - 86400000 * 15).toISOString(), // 15 days ago
  },
  {
    id: 'user-4',
    name: 'Emily Davis',
    email: 'emily@example.com',
    phone: '7778889999',
    totalOrders: 7,
    totalSpent: 249.93,
    createdAt: new Date(Date.now() - 86400000 * 60).toISOString(), // 60 days ago
  },
  {
    id: 'user-5',
    name: 'Michael Wilson',
    email: 'michael@example.com',
    phone: '3334445555',
    totalOrders: 1,
    totalSpent: 29.99,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(), // 5 days ago
  },
  {
    id: 'user-6',
    name: 'Sarah Brown',
    email: 'sarah@example.com',
    phone: '1112223333',
    totalOrders: 4,
    totalSpent: 119.96,
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(), // 20 days ago
  },
  {
    id: 'user-7',
    name: 'David Miller',
    email: 'david@example.com',
    phone: '4445556666',
    totalOrders: 6,
    totalSpent: 179.94,
    createdAt: new Date(Date.now() - 86400000 * 75).toISOString(), // 75 days ago
  },
  {
    id: 'user-8',
    name: 'Jennifer Taylor',
    email: 'jennifer@example.com',
    phone: '6667778888',
    totalOrders: 2,
    totalSpent: 69.98,
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(), // 10 days ago
  },
];

const AdminCustomers: React.FC = () => {
  const [customers, setCustomers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingCustomer, setViewingCustomer] = useState<any>(null);

  useEffect(() => {
    // Simulate loading customers
    setTimeout(() => {
      setCustomers(mockCustomers);
      setIsLoading(false);
    }, 1000);
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const filteredCustomers = customers.filter((customer) =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm)
  );

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Customers - BundleStore Admin</title>
      </Helmet>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Customers</h1>
        </div>

        {/* Search */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="relative max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input pl-10"
            />
          </div>
        </div>

        {/* Customers Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Contact
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Orders
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Spent
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Joined
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                      No customers found
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.map((customer) => (
                    <tr key={customer.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <User size={20} className="text-gray-500" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{customer.name}</div>
                            <div className="text-sm text-gray-500">{customer.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900 flex items-center">
                          <Mail size={14} className="mr-1 text-gray-400" />
                          {customer.email}
                        </div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <Phone size={14} className="mr-1 text-gray-400" />
                          {customer.phone}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {customer.totalOrders}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${customer.totalSpent.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(customer.createdAt)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => setViewingCustomer(customer)}
                          className="text-yellow-600 hover:text-yellow-900"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Customer Details Modal */}
        {viewingCustomer && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b flex justify-between items-center">
                <h2 className="text-xl font-semibold">Customer Details</h2>
                <button
                  onClick={() => setViewingCustomer(null)}
                  className="text-gray-400 hover:text-gray-500"
                >
                  &times;
                </button>
              </div>
              <div className="p-6">
                <div className="flex items-center mb-6">
                  <div className="h-16 w-16 bg-gray-200 rounded-full flex items-center justify-center mr-4">
                    <User size={32} className="text-gray-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">{viewingCustomer.name}</h3>
                    <p className="text-gray-500">Customer since {formatDate(viewingCustomer.createdAt)}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Contact Information</h4>
                    <div className="bg-gray-50 p-4 rounded-md">
                      <div className="flex items-center mb-2">
                        <Mail size={16} className="text-gray-400 mr-2" />
                        <span>{viewingCustomer.email}</span>
                      </div>
                      <div className="flex items-center">
                        <Phone size={16} className="text-gray-400 mr-2" />
                        <span>{viewingCustomer.phone}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">Order Summary</h4>
                    <div className="bg-gray-50 p-4 rounded-md">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <ShoppingBag size={16} className="text-gray-400 mr-2" />
                          <span>Total Orders</span>
                        </div>
                        <span className="font-medium">{viewingCustomer.totalOrders}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="text-gray-400 mr-2">$</span>
                          <span>Total Spent</span>
                        </div>
                        <span className="font-medium">${viewingCustomer.totalSpent.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={() => setViewingCustomer(null)}
                    className="btn btn-primary"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default AdminCustomers;