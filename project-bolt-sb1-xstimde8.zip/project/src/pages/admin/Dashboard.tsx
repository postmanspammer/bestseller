import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useSelector } from 'react-redux';
import { RootState } from '../../store';
import { BarChart, LineChart, DollarSign, Users, Package, ShoppingBag, TrendingUp, ArrowUpRight, ArrowDownRight } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);
  const [isLoading, setIsLoading] = useState(true);
  
  // Mock dashboard data
  const [dashboardData, setDashboardData] = useState({
    totalSales: 0,
    totalOrders: 0,
    totalCustomers: 0,
    totalProducts: 0,
    recentOrders: [],
    salesData: [],
  });

  useEffect(() => {
    // Simulate API call to fetch dashboard data
    setTimeout(() => {
      setDashboardData({
        totalSales: 12589.99,
        totalOrders: 156,
        totalCustomers: 89,
        totalProducts: 4,
        recentOrders: [
          {
            id: 'ORD-001',
            customer: 'John Doe',
            amount: 29.99,
            status: 'completed',
            date: '2023-05-15T10:30:00Z',
          },
          {
            id: 'ORD-002',
            customer: 'Jane Smith',
            amount: 49.99,
            status: 'processing',
            date: '2023-05-14T14:20:00Z',
          },
          {
            id: 'ORD-003',
            customer: 'Robert Johnson',
            amount: 19.99,
            status: 'completed',
            date: '2023-05-14T09:15:00Z',
          },
          {
            id: 'ORD-004',
            customer: 'Emily Davis',
            amount: 99.99,
            status: 'completed',
            date: '2023-05-13T16:45:00Z',
          },
          {
            id: 'ORD-005',
            customer: 'Michael Wilson',
            amount: 39.99,
            status: 'processing',
            date: '2023-05-13T11:30:00Z',
          },
        ],
        salesData: [
          { date: 'Jan', amount: 1200 },
          { date: 'Feb', amount: 1900 },
          { date: 'Mar', amount: 1500 },
          { date: 'Apr', amount: 2100 },
          { date: 'May', amount: 2400 },
        ],
      });
      setIsLoading(false);
    }, 1500);
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Admin Dashboard - BundleStore</title>
      </Helmet>
      
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <div className="text-sm text-gray-500">
            Welcome back, {user?.name}
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm mb-1">Total Sales</p>
                <h3 className="text-2xl font-bold">${dashboardData.totalSales.toLocaleString()}</h3>
                <div className="flex items-center mt-2 text-sm text-green-600">
                  <ArrowUpRight size={14} className="mr-1" />
                  <span>12% from last month</span>
                </div>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <DollarSign size={24} className="text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm mb-1">Total Orders</p>
                <h3 className="text-2xl font-bold">{dashboardData.totalOrders}</h3>
                <div className="flex items-center mt-2 text-sm text-green-600">
                  <ArrowUpRight size={14} className="mr-1" />
                  <span>8% from last month</span>
                </div>
              </div>
              <div className="bg-yellow-100 p-3 rounded-lg">
                <ShoppingBag size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 text-sm mb-1">Total Customers</p>
                <h3 className="text-2xl font-bold">{dashboardData.totalCustomers}</h3>
                <div className="flex items-center mt-2 text-sm text-green-600">
                  <ArrowUpRight size={14} className="mr-1" />
                  <span>5% from last month</span>
                </div>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <Users size={24} className=" <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                          Phone Number
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Phone size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="tel"
                            id="phone"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            className="input pl-10"
                            placeholder="Enter the number to receive the data bundle"
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="btn btn-primary px-8 py-3 flex items-center"
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <CreditCard size={20} className="mr-2" />
                      Complete Payment
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-24">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

              <div className="divide-y">
                {items.map((item) => (
                  <div key={`${item.id}-${item.size}`} className="py-3 flex justify-between">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-gray-500">
                        {item.size} × {item.quantity}
                      </p>
                    </div>
                    <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}
              </div>

              <div className="border-t mt-4 pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="font-medium">$0.00</span>
                </div>
                <div className="border-t pt-2 flex justify-between">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-xl">${totalAmount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CheckoutPage;
  )
}